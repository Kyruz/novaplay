            <?php
                include 'blocks/siteStart.php';
                include 'blocks/top_content.php';
                include 'blocks/mainMenu.php';
                include 'blocks/perfumes_content.php';
                include 'blocks/bot_content.php';
                include 'blocks/siteEnd.php'
            ?>
