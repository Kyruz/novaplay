<div class="midStruct">
    <?php
        
        include 'dbScripts/dbConnect.php';
        include 'dbScripts/dbDisconect.php';
        
        $xml=simplexml_load_file("