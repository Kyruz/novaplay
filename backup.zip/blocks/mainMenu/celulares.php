    <div class="subM_left">
        <p class="smTitle">Celulares</p>
        <p class="links"><a href="#">iPhone</a></p>
        <p class="links"><a href="#">Samsung</a></p>
        <p class="links"><a href="#">Motorola</a></p>
        <p class="links"><a href="#">Blackberry</a></p>
        <p class="links"><a href="#">Blu</a></p>
        <p class="links"><a href="#">Nokia</a></p>
        <p class="links"><a href="#">LG</a></p>
        <p class="links"><a href="#">Sony</a></p>
        <p class="links"><a href="#">Alcatel</a></p>
        <p class="links"><a href="#">freecel</a></p>
    </div>
    <div class="subM_right">
        <img src="media/img/promoCel.png"/>
    </div>