
    <div class="subM_left">
        <p class="smTitle">Armazenamento</p>
        <p class="links"><a href="#">HD's externos</a></p>
        <p class="links"><a href="#">Pen Drive / Cartão de memória</a></p>
        <p class="links"><a href="#">Midias virgens</a></p>
        <p class="links"><a href="#">HD interno / Disco rígido</a></p>
        <p class="links"><a href="#">Outros</a></p>
    </div>
    <div class="subM_right">
        <img src="media/img/promoArmaz.png"/>
    </div>