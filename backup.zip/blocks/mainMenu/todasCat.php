    <div class="subM_left">
        <p class="smTitle">Informática</p>
        <p class="links"><a href="#">Notebooks/Ultrabooks</a></p>
        <p class="links"><a href="#">Impressoras e Multifuncionais</a></p>
        <p class="links"><a href="#">Datashows</a></p>
        <p class="links"><a href="#">Energia</a></p>
        <p class="links"><a href="#">Computadores</a></p>
        <p class="links"><a href="#">Monitores</a></p>
        <p class="links"><a href="#">Componentes e Peças</a></p>
        <p class="links"><a href="#">Rede/Wireless</a></p>
        <p class="links"><a href="#">Suprimentos</a></p>
        <p class="links"><a href="#">Automação Comercial</a></p>
        <p class="smTitle">Celulares</p>
        <p class="links"><a href="#">iPhone</a></p>
        <p class="links"><a href="#">Samsung</a></p>
        <p class="links"><a href="#">Motorola</a></p>
        <p class="links"><a href="#">Blu</a></p>
        <p class="links"><a href="#">Nokia</a></p>
        <p class="links"><a href="#">LG</a></p>
        <p class="links"><a href="#">Sony</a></p>
        <p class="links"><a href="#">Alcatel</a></p>
        <p class="links"><a href="#">freecel</a></p>
        <p class="smTitle">Consoles e Acessórios</p>
        <p class="links"><a href="#">Playstation 4</a></p>
        <p class="links"><a href="#">Playstation 3</a></p>
        <p class="links"><a href="#">Xbox One</a></p>
        <p class="links"><a href="#">Xbox 360</a></p>
        <p class="smTitle">Jogos</p>
        <p class="links"><a href="#">Playstation 4</a></p>
        <p class="links"><a href="#">Playstation 3</a></p>
        <p class="links"><a href="#">Xbox One</a></p>
        <p class="links"><a href="#">Xbox 360</a></p>
        <p class="smTitle">Outros Consoles</p>
        <p class="links"><a href="#">Nintendo Wii U</a></p>
        <p class="links"><a href="#">Playstation 2</a></p>
        <p class="smTitle">Tablets</p>
        <p class="links"><a href="#">Samsung</a></p>
        <p class="links"><a href="#">STi</a></p>
        <p class="links"><a href="#">Philco</a></p>
        <p class="links"><a href="#">Genesis</a></p>
        <p class="links"><a href="#">CCE</a></p>
        <p class="links"><a href="#">Phaser</a></p>
        <p class="links"><a href="#">Space BR</a></p>
        <p class="links"><a href="#">Bright</a></p>
        <p class="smTitle">Automotivos</p>
        <p class="links"><a href="#">Som automotivo</a></p>
        <p class="links"><a href="#">GPS</a></p>
        <p class="links"><a href="#">Acessórios automotivos</a></p>
        <p class="smTitle">Eletrônicos</p>
        <p class="links"><a href="#">Televisões</a></p>
        <p class="links"><a href="#">Filmadoras</a></p>
        <p class="links"><a href="#">Blu-Ray / Dvd players</a></p>
        <p class="links"><a href="#">Calculadoras</a></p>
        <p class="links"><a href="#">Mini System / Rádios</a></p>
        <p class="links"><a href="#">Cameras Digitais</a></p>
        <p class="links"><a href="#">Home Theater</a></p>
        <p class="links"><a href="#">MP3 / MP4</a></p>
        <p class="links"><a href="#">Antenas</a></p>
        <p class="links"><a href="#">Conversor Digital</a></p>
        <p class="links"><a href="#">Lanternas</a></p>
        <p class="smTitle">Acessórios</p>
        <p class="links"><a href="#">Cabos</a></p>
        <p class="links"><a href="#">Adaptadores</a></p>
        <p class="links"><a href="#">Fones de ouvido</a></p>
        <p class="links"><a href="#">Teclados e mouses</a></p>
        <p class="links"><a href="#">Headfones / Headsets</a></p>
        <p class="links"><a href="#">Baterias / Pilhas</a></p>
        <p class="links"><a href="#">Speakers</a></p>
        <p class="links"><a href="#">Carregadores Universais</a><br></p>
        <p class="links"><a href="#">Diversos</a></p>
        <p class="smTitle">Armazenamento</p>
        <p class="links"><a href="#">HD's externos</a></p>
        <p class="links"><a href="#">Pen Drive / Cartão de memória</a></p>
        <p class="links"><a href="#">Midias virgens</a></p>
        <p class="links"><a href="#">HD interno / Disco rígido</a></p>
        <p class="links"><a href="#">Outros</a></p>
        <p class="smTitle">Perfumaria</p>
        <p class="links"><a href="#">Feminino</a></p>
        <p class="links"><a href="#">Masculino</a></p>
        <p class="links"><a href="#">Unisex</a></p>
    </div>
    <div class="subM_right">
        <img src="media/img/promoGeral.png"/>
    </div>