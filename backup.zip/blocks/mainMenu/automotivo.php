    <div class="subM_left">
        <p class="smTitle">Automotivos</p>
        <p class="links"><a href="#">Som automotivo</a></p>
        <p class="links"><a href="#">GPS</a></p>
        <p class="links"><a href="#">Acessórios automotivos</a></p>
    </div>
    <div class="subM_right">
        <img src="media/img/promoAuto.png"/>
    </div>