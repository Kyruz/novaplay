<div class="subM_left">
    <p class="smTitle">Informática</p>
    <p class="links"><a href="#">Notebooks/Ultrabooks</a></p>
    <p class="links"><a href="#">Teclados e mouses</a></p>
    <p class="links"><a href="#">Impressoras e Multifuncionais</a></p>
    <p class="links"><a href="#">Headfones / Headsets</a></p>
    <p class="links"><a href="#">Datashows</a></p>
    <p class="links"><a href="#">Energia</a></p>
    <p class="links"><a href="#">Computadores</a></p>
    <p class="links"><a href="#">Monitores</a></p>
    <p class="links"><a href="#">Componentes e Peças</a></p>
    <p class="links"><a href="#">Rede/Wireless</a></p>
    <p class="links"><a href="#">Suprimentos</a></p>
    <p class="links"><a href="#">Automação Comercial</a></p>
</div>
<div class="subM_right">
    <img src="media/img/promoInform.png"/>
</div>