    <div class="subM_left">
        <p class="smTitle">Tablets</p>
        <p class="links"><a href="#">iPad</a></p>
        <p class="links"><a href="#">Samsung</a></p>
        <p class="links"><a href="#">STi</a></p>
        <p class="links"><a href="#">Philco</a></p>
        <p class="links"><a href="#">Genesis</a></p>
        <p class="links"><a href="#">CCE</a></p>
        <p class="links"><a href="#">Phaser</a></p>
        <p class="links"><a href="#">Space BR</a></p>
        <p class="links"><a href="#">Bright</a></p>
    </div>
    <div class="subM_right">
        <img src="media/img/promoTablet.png"/>
    </div>