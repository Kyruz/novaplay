    <div class="subM_left">
        <p class="smTitle">Acessórios</p>
        <p class="links"><a href="#">Cabos</a></p>
        <p class="links"><a href="#">Adaptadores</a></p>
        <p class="links"><a href="#">Fones de ouvido</a></p>
        <p class="links"><a href="#">Teclados e mouses</a></p>
        <p class="links"><a href="#">Headfones / Headsets</a></p>
        <p class="links"><a href="#">Baterias / Pilhas</a></p>
        <p class="links"><a href="#">Speakers</a></p>
        <p class="links"><a href="#">Carregadores Universais</a><br></p>
        <p class="links"><a href="#">Diversos</a></p>
    </div>
    <div class="subM_right">
        <img src="media/img/promoAcess.png"/>
    </div>