    <div class="subM_left">
        <p class="smTitle">Perfumaria</p>
        <p class="links"><a href="#">Feminino</a></p>
        <p class="links"><a href="#">Masculino</a></p>
        <p class="links"><a href="#">Unisex</a></p>
    </div>
    <div class="subM_right">
        <img src="media/img/promoPerf.png"/>
    </div>