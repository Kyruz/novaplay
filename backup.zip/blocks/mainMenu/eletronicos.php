
    <div class="subM_left">
        <p class="smTitle">Eletrônicos</p>
        <p class="links"><a href="#">Televisões</a></p>
        <p class="links"><a href="#">Telefonia Fixa</a></p>
        <p class="links"><a href="#">Filmadoras</a></p>
        <p class="links"><a href="#">Blu-Ray / Dvd players</a></p>
        <p class="links"><a href="#">Calculadoras</a></p>
        <p class="links"><a href="#">Mini System / Rádios</a></p>
        <p class="links"><a href="#">Cameras Digitais</a></p>
        <p class="links"><a href="#">Home Theater</a></p>
        <p class="links"><a href="#">MP3 / MP4</a></p>
        <p class="links"><a href="#">Antenas</a></p>
        <p class="links"><a href="#">Conversor Digital</a></p>
        <p class="links"><a href="#">Lanternas</a></p>
    </div>
    <div class="subM_right">
        <img src="media/img/promoEletro.png"/>
    </div>
