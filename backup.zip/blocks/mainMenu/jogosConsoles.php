    <div class="subM_left">
        <p class="smTitle">Consoles e Acessórios</p>
        <p class="links"><a href="#">Playstation 4</a></p>
        <p class="links"><a href="#">Playstation 3</a></p>
        <p class="links"><a href="#">Xbox One</a></p>
        <p class="links"><a href="#">Xbox 360</a></p>
        <p class="smTitle">Jogos</p>
        <p class="links"><a href="#">Playstation 4</a></p>
        <p class="links"><a href="#">Playstation 3</a></p>
        <p class="links"><a href="#">Xbox One</a></p>
        <p class="links"><a href="#">Xbox 360</a></p>
        <p class="smTitle">Outros Consoles</p>
        <p class="links"><a href="#">Nintendo Wii U</a></p>
        <p class="links"><a href="#">Playstation 2</a></p>
    </div>
    <div class="subM_right">
        <img src="media/img/promoGames.png"/>
    </div>