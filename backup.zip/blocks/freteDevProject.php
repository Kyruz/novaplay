<div>
    <form action="frete.php" method="post">
        <div style="margin: auto; padding: 10px; display: table;">
            <table>
                <tr>
                    <td>
                        
                    </td>
                    <td>
                        
                    </td>
                </tr>
                <tr>
                    <td>
                        
                    </td>
                    <td>
                        
                    </td>
                </tr>
                <tr>
                    <td>
                        
                    </td>
                    <td>
                        
                    </td>
                </tr>
            </table>
            <!--
            <div style="float: left; padding-bottom: 10px;">
                <label for="sCepOrigem">Cep de Origem (somente números): </label>
                <br>
                <label for="sCepDestino">Cep de Destino (somente números): </label>
                <br>
                <label for="nVlPeso">Peso Total (Kg): </label>
                <br>
                <label for="nVlComprimento">Comprimento da Embalagem (Cm): </label>
                <br>
                <label for="nVlAltura">Altura da Embalagem (Cm): </label>
                <br>
                <label for="nVlLargura">Largura da Embalagem (Cm): </label>
                <br>
                <label for="nCdServico">Serviço: </label>
                <br>
            </div>
            <div style="float: left;">
                <input id="sCepOrigem" onkeypress="return txtBoxFormat(this, ’99999999′, event);" type="text" maxlength="8" name="sCepOrigem" />
                <br>
                <input id="sCepDestino" onkeypress="return txtBoxFormat(this, ’99999999′, event);" type="text" maxlength="8" name="sCepDestino" />
                <br>
                <input id="nVlPeso" onkeydown="javascript: return mascaraValor(this,event,5,3);" type="text" maxlength="5" name="nVlPeso" />
                <br>
                <input id="nVlComprimento" onkeypress="return txtBoxFormat(this, ’999′, event);" type="text" maxlength="3" name="nVlComprimento" />
                <br>
                <input id="nVlAltura" onkeypress="return txtBoxFormat(this, ’999′, event);" type="text" maxlength="3" name="nVlAltura" />
                <br>
                <input id="nVlLargura" onkeypress="return txtBoxFormat(this, ’999′, event);" type="text" maxlength="3" name="nVlLargura" />
                <br>
                <select name="nCdServico"><option value="41106">PAC</option></select>SEDEX SEDEX 10 SEDEX HOJE
                <br>
                <input type="submit" value="Calcular Frete" />
                <br>
            </div>
            -->
        </div>
    </form>
</div>