<div>
    <div style="display: table; margin: auto;">
        <h3>Pagina de Login</h3>
        <form>
            <table style="text-align: right;">
                <tr>
                    <td>
                        Email: 
                    </td>
                    <td>
                        <input type="email" name="email" id="email"/>
                    </td>
                </tr>
                <tr>
                    <td>
                        Senha: 
                    </td>
                    <td>
                        <input type="password" name="pass" id="pass" />
                    </td>
                </tr>
                <tr>
                    <td>
                        
                    </td>
                    <td>
                        <input type="submit" value="Entrar" />
                    </td>
                </tr>
            </table>
        </form>
    </div>
</div>