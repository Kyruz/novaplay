CREATE TABLE `cliente` (
  `id_cliente` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(100) NOT NULL,
  `senhaHash` varchar(70) NOT NULL,
  `nome` varchar(100) NOT NULL,
  `nascimento` date DEFAULT NULL,
  `cpf` varchar(20) NOT NULL,
  `rg` varchar(15) NOT NULL,
  `celular` varchar(20) NOT NULL,
  `telFixo` varchar(20) DEFAULT NULL,
  `cep` varchar(20) NOT NULL,
  `estado` varchar(50) NOT NULL,
  `cidade` varchar(70) NOT NULL,
  `bairro` varchar(70) DEFAULT NULL,
  `complemento` varchar(100) DEFAULT NULL,
  `dataAdesao` date NOT NULL,
  `numResi` varchar(15) DEFAULT NULL,
  `codigo_atv` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_cliente`),
  UNIQUE KEY `email` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=20 DEFAULT CHARSET=utf8;

CREATE TRIGGER setDataAdes BEFORE INSERT ON cliente FOR EACH ROW 
IF ( ISNULL(NEW.dataAdesao)) THEN 
	SET NEW.dataAdesao = CURDATE();
END IF;
$$
DELIMITER;