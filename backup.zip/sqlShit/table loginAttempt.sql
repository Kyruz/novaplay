CREATE TABLE `loginattempt` (
  `id_cliente` int(11) NOT NULL,
  `time_s` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
