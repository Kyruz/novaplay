create table cartao(
id_cartao  int unsigned auto_increment primary key,
id_cliente int unsigned,
banco varchar(25),
numero varchar(50)
);