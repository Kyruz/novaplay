CREATE TABLE `produto` (
  `id_produto` int(11) NOT NULL AUTO_INCREMENT,
  `nome_prod` varchar(255) DEFAULT NULL,
  `cod_categoria` int(11) DEFAULT NULL,
  `produtor` varchar(255) DEFAULT NULL,
  `preco` float DEFAULT NULL,
  `qtd_estoque` int(11) DEFAULT NULL,
  `tags` varchar(255) DEFAULT NULL,
  `descricao` varchar(255) DEFAULT NULL,
  `codigo_prod` varchar(8) DEFAULT NULL,
  `desc_blt` float DEFAULT NULL,
  `pack_peso` float DEFAULT '1',
  `pack_altura` int(11) DEFAULT '2',
  `pack_larg` int(11) DEFAULT '11',
  `pack_compr` int(11) DEFAULT '16',
  PRIMARY KEY (`id_produto`),
  FULLTEXT KEY `ft_index` (`nome_prod`,`tags`,`produtor`,`descricao`)
) ENGINE=InnoDB AUTO_INCREMENT=420 DEFAULT CHARSET=utf8;
