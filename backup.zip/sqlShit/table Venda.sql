CREATE TABLE `venda` (
  `id_venda` int(11) NOT NULL AUTO_INCREMENT,
  `id_produto` int(11) DEFAULT NULL,
  `id_cliente` int(11) DEFAULT NULL,
  `data_venda` date DEFAULT NULL,
  `hora_venda` time DEFAULT NULL,
  `met_pag` varchar(63) DEFAULT NULL,
  `total_pago` float DEFAULT NULL,
  `estado_pag` int(11) NOT NULL DEFAULT '0',
  `detalhes` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id_venda`),
  KEY `id_produto` (`id_produto`),
  KEY `id_cliente` (`id_cliente`),
  CONSTRAINT `venda_ibfk_1` FOREIGN KEY (`id_produto`) REFERENCES `produto` (`id_produto`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;
