<?php
    $hostDoor = 'localhost:3306';
    $user = 'play_db_adm';
    $pass = 's5g1re862fh8r1ase7v5s1fs5r';
    $dbName = 'novaplay_db';
    $dbCon = mysqli_connect($hostDoor,$user,$pass,$dbName);
    