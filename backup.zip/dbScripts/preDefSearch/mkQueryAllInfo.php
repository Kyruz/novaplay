<?php $newQuery = mkQuery('produto', 'id_produto, nome_prod, preco', 'cod_categoria IN (1, 2, 3, 4, 7, 8, 10, 9, 11, 12, 28, 29)', 'cod_categoria, produtor, nome_prod');
