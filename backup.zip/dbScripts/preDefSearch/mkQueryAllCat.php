<?php $newQuery = mkQuery('produto', 'id_produto, nome_prod, preco', false, 'cod_categoria, produtor, nome_prod');
