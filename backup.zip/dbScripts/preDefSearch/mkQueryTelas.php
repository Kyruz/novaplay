<?php $newQuery = mkQuery('produto', 'id_produto, nome_prod, preco', 'cod_categoria = 8 AND tags LIKE ("%monitor%")', 'produtor, nome_prod');
