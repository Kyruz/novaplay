<?php $newQuery = mkQuery('produto', 'id_produto, nome_prod, preco', 'cod_categoria IN (29, 30)', 'produtor, nome_prod');
