<?php
define("USER", "play_db_adm");
define("PASS", "s5g1re862fh8r1ase7v5s1fs5r");
define("HOST_DOOR", "localhost:3306");
define("DATABASE", "novaplay_db");
$dbCon = mysqli_connect(HOST_DOOR, USER, PASS, DATABASE);