This is a project of an online store.
The logo, name and some others images are copyrighted, so they shall not be used, reproduced, etc.
The source code, on the other hand, is open. I have used scripts from all around internet for the most diverse purposes, all open as well.
I'm open to opinions, hints or whatever. Obviously, I'll ignore flamming and similar shits.